# This file is responsible for configuring your application
# and its dependencies with the aid of the Mix.Config module
use Mix.Config

# consul url
config :my_server, consul_agent_url: "http://localhost:8500"

# server configs
config :my_server, server_id: 1
config :my_server, appid: 1107226654

config :my_server, port: 6000
config :my_server, protocol: :msgpack

#:android/:ios
config :my_server, platform_type: :ios

config :my_server, whitelist_enabled: true
config :my_server, trade_whitelist_enabled: true

config :my_server, Pay,
  is_use_midas: false,
  is_sandbox: true,
  mod: 64056769,
  cmd: 65536,
  midas_url: "https://sandbox.api.unipay.qq.com",
  android_appkey: "H0XIH7dNAiQZxZ2SigHCkCxXyoSJQ1yl",
  android_appid: "1450016463",
  android_appkey: "HO2fFv2yxlrtRWQkGDgPGqhnwW1boMKh",
  sandbox_android_appkey: "H0XIH7dNAiQZxZ2SigHCkCxXyoSJQ1yl",
  ios_appid: "1450016464",
  ios_appkey: "q7wev3zTFVS1kERiXImDJOx0QUXgXeMO",
  sandbox_ios_appkey: "FUshFL9ce5uBvTSaf8wED92Jl4vapsMm"

# game state report
config :my_server, state_report: false
config :my_server, state_report_table: "tb_my3d_online"
config :my_server, state_report_interval: 1       # 1 mins
config :my_server, report_register_interval: 60   # 60 s
config :my_server, :ecto_repos, [MySql.Repo]

config :my_server, MySql.Repo,
       adapter: Ecto.Adapters.MySQL,
       database: "db_my3d_online",
       port: 3306,
       username: "root",
       password: "cinside",
       hostname: "localhost"

config :my_server, config_base_url: "http://192.168.1.170:5984/develop/"

config :my_server, msdk_host: "http://msdktest.qq.com"

config :my_server, use_tlog: false
config :my_server, tlog_host: 'shanghai.nanhui8.tglog.datacenter.db'
config :my_server, tlog_port: 45460
config :my_server, tlog_separator: "|"

config :my_server, record_path: "log/"
config :my_server, record_segment_separator: "\t"
config :my_server, record_line_separator: "\n"

config :my_server, Scheduler,
  timezone: "Asia/Shanghai",
  jobs: [
    {"0 0 * * 0", {Router, :route, [Groups, {:weekly_timer}]}},
    {"0 0 * * *", {Router, :route, [Groups, {:daily_timer}]}},
    {"5 * * * *", {Auctions, :clear_timeout_item, []}},
    {"0 20 * * *", {Nobility, :grant, []}},
    {"0 0 * * * *", {Avatar.Supervisor, :broadcast, [{{:TaskSystem, :reset_data}, []}]}}
  ]

# external services
config :my_server, redis_url: "redis://127.0.0.1:6379/7"

config :my_server, boot_up_time: {{2018, 9, 11}, {9, 00, 00}}

config :my_server, Mongo,
  hostname: "127.0.0.1",
  port: 27017,
  database: "moyu_db_sx_longkui"

# disable tzdata auto update
config :tzdata, autoupdate: :disabled
config :timex, local_timezone: "Asia/Shanghai"

config :logger, backends: [:console, {LoggerFileBackend, :debug}]

config :logger, :console, format: "<=====$time $metadata[$level] ======>\n\n $levelpad$message\n\n",
  metadata: [:module, :function, :line], level: :info

config :logger, :debug, path: "./realm.log", rotate: %{max_bytes: 10485760, keep: 30}
config :pid_file, file: "./realm.pid"

# import_config "#{Mix.env}.exs"
config :my_server, load_config: false
